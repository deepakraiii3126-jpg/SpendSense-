import React, { useState, useEffect } from 'react';
import { User, LogOut } from 'lucide-react';
import { Header } from './components/Header';
import { BalanceCard } from './components/BalanceCard';
import { EmergencySavingsCard } from './components/EmergencySavingsCard';
import { BudgetHealthCard } from './components/BudgetHealthCard';
import { RecentTransactions } from './components/RecentTransactions';
import { AddTransactionModal } from './components/AddTransactionModal';
import { TransactionReceiptModal } from './components/TransactionReceiptModal';
import { VaultsView } from './components/VaultsView';
import { AnalyticsView } from './components/AnalyticsView';
import { DesignSystemModal } from './components/DesignSystemModal';
import { NotificationsModal } from './components/NotificationsModal';
import { BottomNav, TabType } from './components/BottomNav';
import { ProfileModal } from './components/ProfileModal';
import { SplashScreen } from './components/SplashScreen';
import { LoginScreen } from './components/LoginScreen';
import {
  initialProfile,
  initialTransactions,
  initialCategoryBudgets,
  initialSavingsGoals,
} from './data/initialData';
import { Transaction, CategoryBudget, SavingsGoal, UserProfile } from './types';

export default function App() {
  // Persistent state initialized from localStorage or defaults
  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('spendsense_profile') || localStorage.getItem('spensense_profile');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (
          parsed.currencySymbol === '$' ||
          parsed.currency === 'USD' ||
          parsed.name === 'Sarah Jenkins' ||
          !parsed.name
        ) {
          return initialProfile;
        }
        return {
          ...parsed,
          name: parsed.name === 'Sarah Jenkins' ? 'Dizz' : parsed.name,
          avatarUrl: '',
          handle: '',
        };
      } catch {
        return initialProfile;
      }
    }
    return initialProfile;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('spendsense_transactions') || localStorage.getItem('spensense_transactions');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].amount < 300) {
          return initialTransactions;
        }
        return parsed;
      } catch {
        return initialTransactions;
      }
    }
    return initialTransactions;
  });

  const [categoryBudgets, setCategoryBudgets] = useState<CategoryBudget[]>(() => {
    const saved = localStorage.getItem('spendsense_budgets') || localStorage.getItem('spensense_budgets');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].allocated < 5000) {
          return initialCategoryBudgets;
        }
        return parsed;
      } catch {
        return initialCategoryBudgets;
      }
    }
    return initialCategoryBudgets;
  });

  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>(() => {
    const saved = localStorage.getItem('spendsense_goals') || localStorage.getItem('spensense_goals');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].targetAmount < 20000) {
          return initialSavingsGoals;
        }
        return parsed;
      } catch {
        return initialSavingsGoals;
      }
    }
    return initialSavingsGoals;
  });

  // Navigation & Modal state
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [isDesignSystemOpen, setIsDesignSystemOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  // Splash & Authentication state
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('spendsense_auth') === 'true';
  });

  const handleLogin = (userName?: string) => {
    if (userName && userName.trim() && userName !== profile.name) {
      setProfile((prev) => ({ ...prev, name: userName.trim() }));
    }
    localStorage.setItem('spendsense_auth', 'true');
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('spendsense_auth');
    setIsAuthenticated(false);
  };

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('spendsense_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('spendsense_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('spendsense_budgets', JSON.stringify(categoryBudgets));
  }, [categoryBudgets]);

  useEffect(() => {
    localStorage.setItem('spendsense_goals', JSON.stringify(savingsGoals));
  }, [savingsGoals]);

  // Derived financial computations
  const totalIncome = transactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpenses = transactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  // Dynamic net balance baseline
  const baseStartingCapital = profile.currencySymbol === '₹' ? 185450.00 : 11650.70;
  const netBalance = baseStartingCapital + (totalIncome - totalExpenses);

  // Primary emergency goal
  const emergencyGoal = savingsGoals.find((g) => g.id === 'goal-emergency') || savingsGoals[0];

  // Actions
  const handleAddTransaction = (newTxData: Omit<Transaction, 'id'>) => {
    const newTx: Transaction = {
      ...newTxData,
      id: `tx-${Date.now()}`,
    };
    setTransactions((prev) => [newTx, ...prev]);

    // If it's an expense, update matching category budget spent
    if (newTx.type === 'expense') {
      setCategoryBudgets((prev) =>
        prev.map((cat) => {
          if (
            cat.name.toLowerCase().includes(newTx.category.toLowerCase()) ||
            newTx.category.toLowerCase().includes(cat.name.toLowerCase())
          ) {
            const newSpent = cat.spent + newTx.amount;
            return {
              ...cat,
              spent: newSpent,
              isWarning: (newSpent / cat.allocated) >= 0.8,
            };
          }
          return cat;
        })
      );
    }
  };

  const handleDeleteTransaction = (id: string) => {
    const target = transactions.find((t) => t.id === id);
    if (!target) return;

    setTransactions((prev) => prev.filter((t) => t.id !== id));

    // Reverse category budget if expense
    if (target.type === 'expense') {
      setCategoryBudgets((prev) =>
        prev.map((cat) => {
          if (
            cat.name.toLowerCase().includes(target.category.toLowerCase()) ||
            target.category.toLowerCase().includes(cat.name.toLowerCase())
          ) {
            const newSpent = Math.max(0, cat.spent - target.amount);
            return {
              ...cat,
              spent: newSpent,
              isWarning: (newSpent / cat.allocated) >= 0.8,
            };
          }
          return cat;
        })
      );
    }
  };

  const handleDepositToGoal = (goalId: string, amount: number) => {
    setSavingsGoals((prev) =>
      prev.map((g) => {
        if (g.id === goalId) {
          return {
            ...g,
            currentAmount: g.currentAmount + amount,
          };
        }
        return g;
      })
    );
  };

  const handleAddSavingsGoal = (newGoal: Omit<SavingsGoal, 'id'>) => {
    const created: SavingsGoal = {
      ...newGoal,
      id: `goal-${Date.now()}`,
    };
    setSavingsGoals((prev) => [...prev, created]);
  };

  const handleResetData = () => {
    setProfile(initialProfile);
    setTransactions(initialTransactions);
    setCategoryBudgets(initialCategoryBudgets);
    setSavingsGoals(initialSavingsGoals);
    localStorage.clear();
  };

  // 1. Initial Launch Splash Screen
  if (showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  // 2. Authentication Login Screen
  if (!isAuthenticated) {
    return <LoginScreen onLogin={handleLogin} defaultName={profile.name} />;
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#131B2E] flex flex-col selection:bg-[#D1FAE5] selection:text-[#064E3B]">
      {/* Top Application Header */}
      <Header
        selectedPeriod="September 2026"
        onQuickAdd={() => setIsAddModalOpen(true)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        unreadCount={2}
      />

      {/* Main Content View Container */}
      <main className="flex-1 w-full max-w-xl mx-auto px-4 py-4 pb-28 sm:px-5">
        {/* Tab 1: Overview Dashboard */}
        {activeTab === 'overview' && (
          <div className="space-y-4 animate-fade-in">
            {/* 1. Hero Balance Card with display-lg tabular monetary display */}
            <BalanceCard
              totalBalance={netBalance}
              monthlyIncome={totalIncome}
              monthlyExpenses={totalExpenses}
              currencySymbol={profile.currencySymbol}
              onQuickAdd={() => setIsAddModalOpen(true)}
              onViewLedger={() => setActiveTab('ledger')}
            />

            {/* 2. Emergency Savings Card with 10px track & milestone indicator dots */}
            {emergencyGoal && (
              <EmergencySavingsCard
                goal={emergencyGoal}
                currencySymbol={profile.currencySymbol}
                onDeposit={handleDepositToGoal}
                onOpenVaults={() => setActiveTab('vaults')}
              />
            )}

            {/* 3. Monthly Category Budgets Health Card */}
            <BudgetHealthCard
              budgets={categoryBudgets}
              currencySymbol={profile.currencySymbol}
              onOpenAnalytics={() => setActiveTab('analytics')}
            />

            {/* 4. Recent Transactions Ledger with filter chips & 64px row items */}
            <RecentTransactions
              transactions={transactions}
              currencySymbol={profile.currencySymbol}
              onSelectTransaction={(tx) => setSelectedTransaction(tx)}
              onViewAll={() => setActiveTab('ledger')}
              isFullView={false}
            />
          </div>
        )}

        {/* Tab 2: Transaction Ledger */}
        {activeTab === 'ledger' && (
          <div className="space-y-4 animate-fade-in">
            <RecentTransactions
              transactions={transactions}
              currencySymbol={profile.currencySymbol}
              onSelectTransaction={(tx) => setSelectedTransaction(tx)}
              isFullView={true}
            />
          </div>
        )}

        {/* Tab 3: Budget & Analytics */}
        {activeTab === 'analytics' && (
          <AnalyticsView
            budgets={categoryBudgets}
            transactions={transactions}
            monthlyIncome={totalIncome}
            monthlyExpenses={totalExpenses}
            currencySymbol={profile.currencySymbol}
          />
        )}

        {/* Tab 4: Savings Vaults */}
        {activeTab === 'vaults' && (
          <VaultsView
            goals={savingsGoals}
            currencySymbol={profile.currencySymbol}
            onDeposit={handleDepositToGoal}
            onAddGoal={handleAddSavingsGoal}
          />
        )}

        {/* Tab 5: Profile & Settings */}
        {activeTab === 'profile' && (
          <div className="space-y-4 animate-fade-in">
            <div className="bg-white rounded-2xl p-6 border border-[#F1F5F9] elevation-1 text-center">
              <div className="relative inline-block mx-auto mb-3">
                <div className="w-20 h-20 rounded-full bg-[#F1F5F9] border-2 border-[#E2E8F0] flex items-center justify-center text-[#94A3B8] shadow-xs">
                  <User size={38} strokeWidth={1.75} />
                </div>
              </div>
              <h2 className="text-xl font-bold text-[#0F172A]">{profile.name}</h2>

              <div className="mt-5 pt-4 border-t border-[#F1F5F9] flex flex-wrap justify-center gap-2.5">
                <button
                  onClick={() => setIsProfileOpen(true)}
                  className="px-4 py-2 rounded-xl bg-[#059669] text-white text-xs font-semibold hover:bg-[#00855d] transition-all"
                >
                  Edit Preferences
                </button>
                <button
                  onClick={() => setIsDesignSystemOpen(true)}
                  className="px-4 py-2 rounded-xl bg-[#ECFDF5] text-[#064E3B] text-xs font-semibold hover:bg-[#D1FAE5] transition-all"
                >
                  Design Tokens
                </button>
                <button
                  onClick={handleLogout}
                  className="px-4 py-2 rounded-xl bg-[#FFF1F2] text-[#E11D48] text-xs font-semibold hover:bg-[#FFE4E6] transition-all flex items-center gap-1.5 active:scale-95"
                >
                  <LogOut size={13} />
                  <span>Sign Out</span>
                </button>
              </div>

              <div className="mt-3.5 pt-3 border-t border-[#F8FAFC]">
                <button
                  onClick={() => setShowSplash(true)}
                  className="text-xs font-medium text-[#64748B] hover:text-[#059669] transition-colors inline-flex items-center gap-1"
                >
                  <span>Replay Splash Screen</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Pinned Bottom Navigation Bar: Level 3 elevation, backdrop blur 16px, 90% opacity white */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={(tab) => setActiveTab(tab)}
      />

      {/* Add Transaction Modal with currency inset & tactile inputs */}
      <AddTransactionModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddTransaction={handleAddTransaction}
        currencySymbol={profile.currencySymbol}
      />

      {/* Transaction Receipt Modal */}
      <TransactionReceiptModal
        transaction={selectedTransaction}
        onClose={() => setSelectedTransaction(null)}
        onDelete={handleDeleteTransaction}
        currencySymbol={profile.currencySymbol}
      />

      {/* Interactive Design System Token Inspector */}
      <DesignSystemModal
        isOpen={isDesignSystemOpen}
        onClose={() => setIsDesignSystemOpen(false)}
      />

      {/* Real-time Notifications Drawer */}
      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        currencySymbol={profile.currencySymbol}
      />

      {/* User Profile & Preferences Modal */}
      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        profile={profile}
        onUpdateProfile={(updated) => setProfile((p) => ({ ...p, ...updated }))}
        onResetData={handleResetData}
        transactions={transactions}
        onOpenDesignSystem={() => setIsDesignSystemOpen(true)}
        onLogout={handleLogout}
      />
    </div>
  );
}
