import React, { useState } from 'react';
import {
  X,
  Plus,
  ShoppingCart,
  Coffee,
  Briefcase,
  Activity,
  Music,
  Sparkles,
  Zap,
  Car,
  ShoppingBag,
  Calendar,
  CreditCard,
  FileText,
  Tag,
  Check,
} from 'lucide-react';
import { Transaction, TransactionType } from '../types';

interface AddTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTransaction: (newTx: Omit<Transaction, 'id'>) => void;
  currencySymbol: string;
}

const categories = [
  { name: 'Groceries', icon: ShoppingCart, defaultSub: 'Produce & Food' },
  { name: 'Food & Dining', icon: Coffee, defaultSub: 'Restaurants & Cafés' },
  { name: 'Transportation', icon: Car, defaultSub: 'Transit & Fuel' },
  { name: 'Housing & Utilities', icon: Zap, defaultSub: 'Household & Energy' },
  { name: 'Health & Wellness', icon: Activity, defaultSub: 'Gym & Care' },
  { name: 'Entertainment', icon: Music, defaultSub: 'Digital & Media' },
  { name: 'Shopping', icon: ShoppingBag, defaultSub: 'Retail & Personal' },
  { name: 'Income / Salary', icon: Briefcase, defaultSub: 'Earnings & Retainers' },
];

export const AddTransactionModal: React.FC<AddTransactionModalProps> = ({
  isOpen,
  onClose,
  onAddTransaction,
  currencySymbol,
}) => {
  const [type, setType] = useState<TransactionType>('expense');
  const [amount, setAmount] = useState<string>('');
  const [title, setTitle] = useState<string>('');
  const [category, setCategory] = useState<string>('Food & Dining');
  const [subcategory, setSubcategory] = useState<string>('Café & Dining');
  const [paymentMethod, setPaymentMethod] = useState<string>('Apple Pay •• 4921');
  const [notes, setNotes] = useState<string>('');
  const [isSubscription, setIsSubscription] = useState<boolean>(false);
  const [date, setDate] = useState<string>('2026-09-16');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(amount);
    if (isNaN(num) || num <= 0) return;
    if (!title.trim()) return;

    // Pick matching icon
    const matched = categories.find((c) => c.name === category);
    const iconName = matched ? matched.icon.name || 'ShoppingBag' : 'ShoppingBag';

    onAddTransaction({
      title: title.trim(),
      category: type === 'income' ? 'Income' : category,
      subcategory: subcategory || (type === 'income' ? 'Direct Deposit' : category),
      amount: num,
      type,
      date,
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
      paymentMethod,
      notes: notes.trim(),
      status: 'completed',
      icon: iconName,
      isSubscription,
    });

    // Reset
    setAmount('');
    setTitle('');
    setNotes('');
    onClose();
  };

  return (
    <div
      id="add-transaction-modal"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-[#0F172A]/40 backdrop-blur-xs animate-fade-in"
    >
      {/* Modal Surface: Level 3 elevation, rounded-t-2xl sm:rounded-2xl */}
      <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-2xl p-5 sm:p-6 elevation-3 border border-[#E2E8F0] max-h-[92vh] overflow-y-auto">
        {/* Top bar */}
        <div className="flex items-center justify-between pb-3 border-b border-[#F1F5F9] mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#ECFDF5] text-[#059669] flex items-center justify-center">
              <Plus size={18} strokeWidth={2.5} />
            </div>
            <h2 className="text-lg font-bold text-[#0F172A]">
              Record Transaction
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-[#64748B] hover:bg-[#F1F5F9] hover:text-[#0F172A] transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Segmented Switcher: Expense vs Income */}
          <div className="grid grid-cols-2 p-1 bg-[#F1F5F9] rounded-xl">
            <button
              type="button"
              onClick={() => setType('expense')}
              className={`h-10 text-xs font-bold rounded-lg transition-all ${
                type === 'expense'
                  ? 'bg-white text-[#E11D48] shadow-xs'
                  : 'text-[#64748B] hover:text-[#0F172A]'
              }`}
            >
              Expense (Cash Out)
            </button>
            <button
              type="button"
              onClick={() => setType('income')}
              className={`h-10 text-xs font-bold rounded-lg transition-all ${
                type === 'income'
                  ? 'bg-white text-[#059669] shadow-xs'
                  : 'text-[#64748B] hover:text-[#0F172A]'
              }`}
            >
              Income (Cash In)
            </button>
          </div>

          {/* Amount Input with hard-coded currency inset */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#64748B] mb-1.5">
              Monetary Value
            </label>
            <div className="relative h-14 bg-white border-[1.5px] border-[#E2E8F0] rounded-xl flex items-center px-4 focus-within:border-[#059669] focus-within:ring-3 focus-within:ring-[#059669]/20 transition-all">
              <span className="text-2xl font-bold text-[#64748B] mr-2 select-none">
                {currencySymbol}
              </span>
              <input
                type="number"
                step="0.01"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full h-full bg-transparent text-2xl font-bold text-[#0F172A] tabular-nums focus:outline-none placeholder:text-[#CBD5E1]"
                required
                autoFocus
              />
            </div>
          </div>

          {/* Title / Vendor Name */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#64748B] mb-1.5">
              Merchant / Description
            </label>
            <div className="relative h-12 bg-white border-[1.5px] border-[#E2E8F0] rounded-xl flex items-center px-3.5 focus-within:border-[#059669] focus-within:ring-3 focus-within:ring-[#059669]/20 transition-all">
              <input
                type="text"
                placeholder="e.g. Trader Joe's, Uber, Client payment..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-transparent text-sm font-semibold text-[#0F172A] focus:outline-none placeholder:text-[#94A3B8]"
                required
              />
            </div>
          </div>

          {/* Category Selector with Vibrant Badges */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#64748B] mb-1.5">
              Category
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {categories.map((cat) => {
                const Icon = cat.icon;
                const isSelected = category === cat.name;
                return (
                  <button
                    key={cat.name}
                    type="button"
                    onClick={() => {
                      setCategory(cat.name);
                      setSubcategory(cat.defaultSub);
                    }}
                    className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition-all active:scale-95 ${
                      isSelected
                        ? 'border-[#059669] bg-[#ECFDF5] text-[#064E3B] ring-2 ring-[#059669]/20'
                        : 'border-[#E2E8F0] bg-[#F8FAFC] text-[#334155] hover:bg-[#F1F5F9]'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                        isSelected
                          ? 'bg-[#059669] text-white'
                          : 'bg-white text-[#64748B]'
                      }`}
                    >
                      <Icon size={14} />
                    </div>
                    <span className="text-xs font-semibold truncate">
                      {cat.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Payment Method & Date */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#64748B] mb-1.5">
                Payment Instrument
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full h-11 px-3 bg-white border-[1.5px] border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] focus:outline-none focus:border-[#059669] focus:ring-2 focus:ring-[#059669]/20"
              >
                <option value="Apple Pay •• 4921">Apple Pay •• 4921</option>
                <option value="Amex Platinum •• 1004">Amex Platinum •• 1004</option>
                <option value="Debit Card •• 8812">Debit Card •• 8812</option>
                <option value="Checking Direct Transfer">Checking Transfer</option>
                <option value="Cash / Pocket Money">Cash</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#64748B] mb-1.5">
                Transaction Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full h-11 px-3 bg-white border-[1.5px] border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] focus:outline-none focus:border-[#059669] focus:ring-2 focus:ring-[#059669]/20"
              />
            </div>
          </div>

          {/* Recurring / Subscription toggle */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0]">
            <div>
              <span className="text-xs font-bold text-[#0F172A]">
                Recurring Monthly Subscription
              </span>
              <p className="text-[11px] text-[#64748B]">
                Flag for recurring budget tracker
              </p>
            </div>
            <input
              type="checkbox"
              checked={isSubscription}
              onChange={(e) => setIsSubscription(e.target.checked)}
              className="w-5 h-5 accent-[#059669] rounded cursor-pointer"
            />
          </div>

          {/* Action buttons: Primary solid #059669, secondary #D1FAE5 container */}
          <div className="pt-2 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="h-12 px-5 rounded-xl bg-[#F1F5F9] text-[#334155] font-semibold text-sm hover:bg-[#E2E8F0] active:scale-[0.98] transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 h-12 px-6 rounded-xl bg-[#059669] text-white font-semibold text-sm hover:bg-[#00855d] active:scale-[0.98] transition-all shadow-xs flex items-center justify-center gap-2"
            >
              <Check size={18} strokeWidth={2.5} />
              <span>Confirm & Save</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
