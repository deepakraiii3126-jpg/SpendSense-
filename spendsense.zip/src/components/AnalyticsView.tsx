import React from 'react';
import {
  TrendingUp,
  AlertTriangle,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  PieChart,
  Calendar,
  Layers,
} from 'lucide-react';
import { CategoryBudget, Transaction } from '../types';

interface AnalyticsViewProps {
  budgets: CategoryBudget[];
  transactions: Transaction[];
  monthlyIncome: number;
  monthlyExpenses: number;
  currencySymbol: string;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  budgets,
  transactions,
  monthlyIncome,
  monthlyExpenses,
  currencySymbol,
}) => {
  const formatMoney = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(val);
  };

  const totalAllocated = budgets.reduce((s, b) => s + b.allocated, 0);
  const totalSpent = budgets.reduce((s, b) => s + b.spent, 0);
  const savingsRate = Math.round(((monthlyIncome - monthlyExpenses) / monthlyIncome) * 100);

  // Daily average spend calculation
  const daysInMonth = 30;
  const currentDay = 16;
  const daysRemaining = daysInMonth - currentDay;
  const dailyAverage = (monthlyExpenses / currentDay).toFixed(1);
  const projectedMonthly = (parseFloat(dailyAverage) * daysInMonth).toFixed(0);

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Monthly Efficiency Hero */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#F1F5F9] elevation-1">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold uppercase tracking-wider text-[#64748B]">
            Financial Efficiency Score
          </span>
          <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#ECFDF5] text-[#059669] border border-[#A7F3D0]">
            Optimal (A+)
          </span>
        </div>

        <div className="flex items-baseline gap-2">
          <h2 className="text-3xl font-bold text-[#0F172A] tabular-nums">
            {savingsRate}%
          </h2>
          <span className="text-xs text-[#64748B]">
            Net savings margin for September
          </span>
        </div>

        {/* Visual Bar Comparison */}
        <div className="mt-4 pt-3 border-t border-[#F1F5F9]">
          <div className="flex items-center justify-between text-xs font-semibold mb-1.5">
            <span className="text-[#059669]">
              Total Inflow: {currencySymbol}{formatMoney(monthlyIncome)}
            </span>
            <span className="text-[#E11D48]">
              Total Outflow: {currencySymbol}{formatMoney(monthlyExpenses)}
            </span>
          </div>

          <div className="w-full h-3 bg-[#F1F5F9] rounded-full overflow-hidden flex">
            <div
              className="h-full bg-[#059669]"
              style={{ width: `${Math.min(100, (monthlyIncome / (monthlyIncome + monthlyExpenses)) * 100)}%` }}
              title="Income Inflow"
            />
            <div
              className="h-full bg-[#E11D48]"
              style={{ width: `${Math.min(100, (monthlyExpenses / (monthlyIncome + monthlyExpenses)) * 100)}%` }}
              title="Expense Outflow"
            />
          </div>
        </div>

        {/* Key Metrics row */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mt-4">
          <div className="p-2.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0]">
            <span className="text-[11px] text-[#64748B] block font-medium">Daily Burn Rate</span>
            <span className="text-sm font-bold text-[#0F172A] tabular-nums">
              {currencySymbol}{dailyAverage}/day
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0]">
            <span className="text-[11px] text-[#64748B] block font-medium">Projected Spend</span>
            <span className="text-sm font-bold text-[#0F172A] tabular-nums">
              {currencySymbol}{projectedMonthly}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] col-span-2 sm:col-span-1">
            <span className="text-[11px] text-[#64748B] block font-medium">Remaining Budget</span>
            <span className="text-sm font-bold text-[#059669] tabular-nums">
              +{currencySymbol}{formatMoney(totalAllocated - totalSpent)}
            </span>
          </div>
        </div>
      </div>

      {/* Category Breakdown list */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#F1F5F9] elevation-1">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-[#0F172A]">
              Detailed Category Allocation
            </h3>
            <p className="text-xs text-[#64748B]">
              Tracking {budgets.length} active spending envelopes
            </p>
          </div>
          <span className="text-xs font-semibold text-[#064E3B] px-2.5 py-1 rounded-full bg-[#D1FAE5]">
            {daysRemaining} days left in cycle
          </span>
        </div>

        <div className="space-y-4">
          {budgets.map((b) => {
            const pct = Math.round((b.spent / b.allocated) * 100);
            const isAlert = pct >= 80;
            const remaining = b.allocated - b.spent;

            return (
              <div key={b.id} className="p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0]">
                <div className="flex items-center justify-between mb-1 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-[#0F172A] text-sm">
                      {b.name}
                    </span>
                    {isAlert && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#FFFBEB] text-[#D97706] border border-[#FDE68A]">
                        <AlertTriangle size={10} />
                        {pct}% spent
                      </span>
                    )}
                  </div>
                  <div className="font-bold text-[#0F172A] tabular-nums">
                    {currencySymbol}{formatMoney(b.spent)}{' '}
                    <span className="text-[#64748B] font-normal">
                      / {currencySymbol}{formatMoney(b.allocated)}
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full h-2 bg-[#E2E8F0] rounded-full overflow-hidden my-2">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${Math.min(100, pct)}%`,
                      backgroundColor: isAlert ? '#D97706' : '#059669',
                    }}
                  />
                </div>

                <div className="flex justify-between items-center text-[11px] text-[#64748B]">
                  <span>
                    {remaining >= 0 ? (
                      <span className="text-[#059669] font-semibold">
                        {currencySymbol}{formatMoney(remaining)} available
                      </span>
                    ) : (
                      <span className="text-[#E11D48] font-semibold">
                        {currencySymbol}{formatMoney(Math.abs(remaining))} over-budget
                      </span>
                    )}
                  </span>
                  <span>Daily limit: ~{currencySymbol}{Math.max(0, Math.round(remaining / daysRemaining))}/day</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
