import React, { useState } from 'react';
import { TrendingUp, ArrowUpRight, ArrowDownRight, Eye, EyeOff, Plus, Wallet } from 'lucide-react';
import { UserProfile } from '../types';

interface BalanceCardProps {
  totalBalance: number;
  monthlyIncome: number;
  monthlyExpenses: number;
  currencySymbol: string;
  onQuickAdd: () => void;
  onViewLedger: () => void;
}

export const BalanceCard: React.FC<BalanceCardProps> = ({
  totalBalance,
  monthlyIncome,
  monthlyExpenses,
  currencySymbol,
  onQuickAdd,
  onViewLedger,
}) => {
  const [showBalance, setShowBalance] = useState<boolean>(true);

  // Format currency with tabular figures
  const formatAmount = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(val);
  };

  const netSavings = monthlyIncome - monthlyExpenses;
  const savingsPercent = monthlyIncome > 0 ? ((netSavings / monthlyIncome) * 100).toFixed(1) : '0';

  return (
    <div
      id="hero-balance-card"
      className="w-full bg-white rounded-2xl p-4 sm:p-5 border border-[#F1F5F9] elevation-1 relative overflow-hidden transition-all hover:elevation-2"
    >
      {/* Decorative subtle botanical gradient glow in top right */}
      <div className="absolute -top-12 -right-12 w-36 h-36 bg-[#D1FAE5]/30 rounded-full blur-2xl pointer-events-none" />

      {/* Top row: Label & Privacy toggle */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-[#059669]" />
          <span className="text-xs font-semibold uppercase tracking-wider text-[#64748B]">
            Total Net Balance
          </span>
        </div>

        <button
          onClick={() => setShowBalance(!showBalance)}
          className="p-1.5 text-[#64748B] hover:text-[#0F172A] hover:bg-[#F1F5F9] rounded-lg transition-colors"
          title={showBalance ? 'Hide balance' : 'Show balance'}
        >
          {showBalance ? <Eye size={16} /> : <EyeOff size={16} />}
        </button>
      </div>

      {/* Primary Balance display (display-lg-mobile: 32px, sm: 40px, bold 700) */}
      <div className="flex items-baseline gap-1 my-1">
        <span className="text-2xl sm:text-3xl font-semibold text-[#64748B]">
          {currencySymbol}
        </span>
        <h1 className="text-[32px] sm:text-[40px] font-bold tracking-tight text-[#0F172A] leading-none tabular-nums">
          {showBalance ? formatAmount(totalBalance) : '••••••••'}
        </h1>
      </div>

      {/* Month-over-month trend badge */}
      <div className="flex items-center gap-2 mt-2 mb-4">
        <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#ECFDF5] text-[#059669] text-xs font-semibold">
          <TrendingUp size={13} />
          <span>+12.4% vs last month</span>
        </div>
        <span className="text-xs text-[#64748B]">
          Healthy {savingsPercent}% savings rate
        </span>
      </div>

      {/* Split Income and Expense summary cards */}
      <div className="grid grid-cols-2 gap-2.5 sm:gap-3 pt-3 border-t border-[#F1F5F9]">
        {/* Income Card */}
        <div
          onClick={onViewLedger}
          className="bg-[#F8FAFC] hover:bg-[#ECFDF5]/50 cursor-pointer rounded-xl p-3 border border-[#E2E8F0] transition-all group"
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-medium text-[#64748B]">
              Income (Sep)
            </span>
            <div className="w-6 h-6 rounded-full bg-[#ECFDF5] text-[#059669] flex items-center justify-center group-hover:scale-110 transition-transform">
              <ArrowUpRight size={14} />
            </div>
          </div>
          <div className="text-base sm:text-lg font-bold text-[#059669] tabular-nums">
            {showBalance ? `+${currencySymbol}${formatAmount(monthlyIncome)}` : '••••'}
          </div>
        </div>

        {/* Expenses Card */}
        <div
          onClick={onViewLedger}
          className="bg-[#F8FAFC] hover:bg-[#FFF1F2]/50 cursor-pointer rounded-xl p-3 border border-[#E2E8F0] transition-all group"
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-medium text-[#64748B]">
              Spent (Sep)
            </span>
            <div className="w-6 h-6 rounded-full bg-[#FFF1F2] text-[#E11D48] flex items-center justify-center group-hover:scale-110 transition-transform">
              <ArrowDownRight size={14} />
            </div>
          </div>
          <div className="text-base sm:text-lg font-bold text-[#0F172A] tabular-nums">
            {showBalance ? `-${currencySymbol}${formatAmount(monthlyExpenses)}` : '••••'}
          </div>
        </div>
      </div>

      {/* Quick Action Button Bar */}
      <div className="mt-3.5 flex items-center gap-2">
        <button
          onClick={onQuickAdd}
          className="flex-1 flex items-center justify-center gap-2 h-11 px-4 rounded-xl bg-[#059669] text-white font-semibold text-sm hover:bg-[#00855d] active:scale-[0.98] transition-all shadow-xs"
        >
          <Plus size={16} strokeWidth={2.5} />
          <span>Add Transaction</span>
        </button>
        <button
          onClick={onViewLedger}
          className="h-11 px-3.5 rounded-xl bg-[#D1FAE5] text-[#064E3B] hover:bg-[#A7F3D0] active:scale-[0.98] font-semibold text-sm transition-all flex items-center gap-1.5"
          title="Open Ledger"
        >
          <Wallet size={16} />
          <span className="hidden xs:inline">Ledger</span>
        </button>
      </div>
    </div>
  );
};
