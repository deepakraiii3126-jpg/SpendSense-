import React from 'react';
import { Home, ReceiptText, PieChart, ShieldCheck, User } from 'lucide-react';

export type TabType = 'overview' | 'ledger' | 'analytics' | 'vaults' | 'profile';

interface BottomNavProps {
  activeTab: TabType;
  onChangeTab: (tab: TabType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
}) => {
  const navItems = [
    { id: 'overview' as TabType, label: 'Overview', icon: Home },
    { id: 'ledger' as TabType, label: 'Ledger', icon: ReceiptText },
    { id: 'analytics' as TabType, label: 'Budget', icon: PieChart },
    { id: 'vaults' as TabType, label: 'Vaults', icon: ShieldCheck },
    { id: 'profile' as TabType, label: 'Profile', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/90 backdrop-blur-md border-t border-[#F1F5F9] elevation-3 pb-safe">
      <div className="max-w-xl mx-auto px-4 h-16 flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onChangeTab(item.id)}
              className={`flex flex-col items-center justify-center w-14 h-full py-1 transition-colors active:scale-95 ${
                isActive ? 'text-[#064E3B]' : 'text-[#64748B] hover:text-[#0F172A]'
              }`}
            >
              <div
                className={`p-1 rounded-xl transition-all ${
                  isActive ? 'bg-[#ECFDF5] text-[#059669]' : 'text-[#64748B]'
                }`}
              >
                <Icon size={20} strokeWidth={isActive ? 2.3 : 1.8} />
              </div>
              <span
                className={`text-[11px] mt-0.5 tracking-tight ${
                  isActive ? 'font-bold text-[#064E3B]' : 'font-medium'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
