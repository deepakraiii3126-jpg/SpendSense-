import React from 'react';
import {
  PieChart,
  Utensils,
  Home,
  Car,
  HeartPulse,
  Film,
  ShoppingBag,
  AlertTriangle,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { CategoryBudget } from '../types';

interface BudgetHealthCardProps {
  budgets: CategoryBudget[];
  currencySymbol: string;
  onOpenAnalytics: () => void;
}

const iconMap: Record<string, React.ElementType> = {
  Utensils,
  Home,
  Car,
  HeartPulse,
  Film,
  ShoppingBag,
};

export const BudgetHealthCard: React.FC<BudgetHealthCardProps> = ({
  budgets,
  currencySymbol,
  onOpenAnalytics,
}) => {
  const totalAllocated = budgets.reduce((sum, b) => sum + b.allocated, 0);
  const totalSpent = budgets.reduce((sum, b) => sum + b.spent, 0);
  const totalPercentage = Math.round((totalSpent / totalAllocated) * 100);

  const formatMoney = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(val);
  };

  return (
    <div
      id="budget-health-card"
      className="w-full bg-white rounded-2xl p-4 sm:p-5 border border-[#F1F5F9] elevation-1 hover:elevation-2 transition-all"
    >
      {/* Card Header with 40px circular container #ECFDF5 fill and #059669 iconography */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#ECFDF5] text-[#059669] flex items-center justify-center border border-[#D1FAE5] shrink-0">
            <PieChart size={20} />
          </div>
          <div>
            <h2 className="text-base font-bold text-[#0F172A]">
              Monthly Category Budgets
            </h2>
            <p className="text-xs text-[#64748B]">
              {currencySymbol}{formatMoney(totalSpent)} spent of {currencySymbol}{formatMoney(totalAllocated)} ({totalPercentage}%)
            </p>
          </div>
        </div>

        <button
          onClick={onOpenAnalytics}
          className="text-xs font-semibold text-[#059669] hover:text-[#006948] flex items-center gap-0.5 p-1 transition-colors"
        >
          <span>Analytics</span>
          <ChevronRight size={14} />
        </button>
      </div>

      {/* Category Progress List */}
      <div className="space-y-3.5">
        {budgets.slice(0, 4).map((category) => {
          const Icon = iconMap[category.icon] || ShoppingBag;
          const pct = Math.round((category.spent / category.allocated) * 100);
          const isWarning = pct >= 80;
          const isOver = pct > 100;

          return (
            <div key={category.id} className="group">
              <div className="flex items-center justify-between mb-1.5 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-[#F1F5F9] text-[#334155] flex items-center justify-center group-hover:bg-[#ECFDF5] group-hover:text-[#059669] transition-colors">
                    <Icon size={14} />
                  </div>
                  <span className="font-semibold text-[#0F172A]">
                    {category.name}
                  </span>
                  {isWarning && (
                    <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      isOver
                        ? 'bg-[#FFF1F2] text-[#E11D48] border border-[#FECDD3]'
                        : 'bg-[#FFFBEB] text-[#D97706] border border-[#FDE68A]'
                    }`}>
                      <AlertTriangle size={10} />
                      {isOver ? 'Over budget' : '80%+ spent'}
                    </span>
                  )}
                </div>

                <div className="text-right">
                  <span className="font-bold text-[#0F172A] tabular-nums">
                    {currencySymbol}{formatMoney(category.spent)}
                  </span>
                  <span className="text-[#64748B] tabular-nums font-normal">
                    {' '}/ {currencySymbol}{formatMoney(category.allocated)}
                  </span>
                </div>
              </div>

              {/* Progress track */}
              <div className="w-full h-2 bg-[#F1F5F9] rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(100, pct)}%`,
                    backgroundColor: isOver
                      ? '#E11D48'
                      : isWarning
                      ? '#D97706'
                      : '#059669',
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Card Footer */}
      <div className="mt-4 pt-3 border-t border-[#F1F5F9] flex items-center justify-between text-xs">
        <span className="text-[#64748B] flex items-center gap-1">
          <Sparkles size={13} className="text-[#059669]" />
          Pace is on track for 14 days remaining
        </span>
        <button
          onClick={onOpenAnalytics}
          className="font-semibold text-[#059669] hover:underline"
        >
          View all 6 categories →
        </button>
      </div>
    </div>
  );
};
