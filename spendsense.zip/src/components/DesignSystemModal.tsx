import React, { useState } from 'react';
import { X, Sparkles, Check, Copy, Palette, Type, Box, ShieldCheck, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { SpenSenseLogo } from './SpenSenseLogo';

interface DesignSystemModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DesignSystemModal: React.FC<DesignSystemModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copiedHex, setCopiedHex] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 1500);
  };

  const paletteGroups = [
    {
      name: 'Primary & Botanical Accents',
      colors: [
        { name: 'Primary Core', hex: '#059669', text: '#FFFFFF', role: 'Interactive callouts & active states' },
        { name: 'Primary Deep', hex: '#006948', text: '#FFFFFF', role: 'Solid brand anchor' },
        { name: 'Primary Container', hex: '#00855d', text: '#FFFFFF', role: 'High-emphasis fills' },
        { name: 'Secondary Forest', hex: '#064E3B', text: '#FFFFFF', role: 'Authority headers & active chips' },
        { name: 'Tertiary Vibrant', hex: '#10B981', text: '#FFFFFF', role: 'Positive trend lines & badges' },
        { name: 'Mint Tint', hex: '#D1FAE5', text: '#064E3B', role: 'Progress tracks & secondary actions' },
        { name: 'Sage Soft', hex: '#ECFDF5', text: '#059669', role: 'Category badges & income surface' },
      ],
    },
    {
      name: 'Semantic Status',
      colors: [
        { name: 'Income / Surplus', hex: '#059669', text: '#FFFFFF', role: 'Cash in / positive adjustments' },
        { name: 'Expense / Alert', hex: '#E11D48', text: '#FFFFFF', role: 'Cash out / over-budget notices' },
        { name: 'Goal Warning', hex: '#D97706', text: '#FFFFFF', role: '80%+ budget threshold alerts' },
      ],
    },
    {
      name: 'Structural Neutrals & Surfaces',
      colors: [
        { name: 'Slate Dark (900)', hex: '#0F172A', text: '#FFFFFF', role: 'Primary ledger values & headings' },
        { name: 'Slate Body (700)', hex: '#334155', text: '#FFFFFF', role: 'Standard descriptive copy' },
        { name: 'Slate Muted (500)', hex: '#64748B', text: '#FFFFFF', role: 'Labels & currency prefixes' },
        { name: 'Border Slate (200)', hex: '#E2E8F0', text: '#0F172A', role: 'Card outlines & field containers' },
        { name: 'App Base Canvas', hex: '#F8FAFC', text: '#0F172A', role: 'Level 0 background foundation' },
      ],
    },
  ];

  return (
    <div
      id="design-system-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-[#0F172A]/40 backdrop-blur-xs animate-fade-in"
    >
      <div className="w-full max-w-2xl bg-white rounded-2xl elevation-3 border border-[#E2E8F0] max-h-[90vh] flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-[#F1F5F9] flex items-center justify-between bg-[#FAFAFA]">
          <div className="flex items-center gap-3">
            <SpenSenseLogo size={32} />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-[#0F172A]">
                  SpendSense Design System
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#ECFDF5] text-[#059669] border border-[#A7F3D0]">
                  Tactile Modern Fintech
                </span>
              </div>
              <p className="text-xs text-[#64748B]">
                Token architecture, botanical emeralds, and tactile baseline
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-[#64748B] hover:bg-white transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Scroll Content */}
        <div className="p-5 overflow-y-auto space-y-6 text-xs text-[#334155]">
          {/* Movement Summary */}
          <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0]">
            <h4 className="font-bold text-[#0F172A] text-sm mb-1 flex items-center gap-1.5">
              <Sparkles size={15} className="text-[#059669]" />
              Design Movement: Modern Tactile Fintech
            </h4>
            <p className="text-[#64748B] leading-relaxed">
              Pristine surfaces with emerald accenting replace transactional anxiety with clarity.
              Subtle inner glows, softened tinted elevations, and tabular monetary figures give financial values tactile weight.
            </p>
          </div>

          {/* Color Palettes */}
          <div>
            <h4 className="font-bold text-[#0F172A] text-sm mb-3 flex items-center gap-1.5">
              <Palette size={15} className="text-[#059669]" />
              Color Architecture Tokens
            </h4>

            <div className="space-y-4">
              {paletteGroups.map((group) => (
                <div key={group.name}>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-[#64748B] mb-2">
                    {group.name}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {group.colors.map((c) => (
                      <div
                        key={c.name}
                        onClick={() => copyToClipboard(c.hex)}
                        className="flex items-center justify-between p-2 rounded-xl border border-[#E2E8F0] hover:bg-[#F8FAFC] cursor-pointer transition-colors group"
                      >
                        <div className="flex items-center gap-2.5">
                          <div
                            className="w-8 h-8 rounded-lg shadow-xs flex items-center justify-center font-bold shrink-0 border border-black/5"
                            style={{ backgroundColor: c.hex, color: c.text }}
                          >
                            {copiedHex === c.hex ? <Check size={14} /> : ''}
                          </div>
                          <div>
                            <div className="font-semibold text-[#0F172A] text-xs">
                              {c.name}
                            </div>
                            <div className="text-[10px] text-[#64748B]">
                              {c.role}
                            </div>
                          </div>
                        </div>

                        <span className="font-mono text-[11px] text-[#64748B] group-hover:text-[#059669] group-hover:font-bold">
                          {c.hex}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Elevation Tokens */}
          <div>
            <h4 className="font-bold text-[#0F172A] text-sm mb-2.5 flex items-center gap-1.5">
              <Box size={15} className="text-[#059669]" />
              Elevation & Forest-Tinted Shadows
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-white rounded-xl border border-[#F1F5F9] elevation-1">
                <span className="font-bold text-[#0F172A] block text-xs">Level 1: Card Rest</span>
                <span className="text-[10px] text-[#64748B] block mt-0.5">
                  0px 1px 3px rgba(15, 23, 42, 0.04), 4px 12px forest slate
                </span>
              </div>
              <div className="p-3 bg-white rounded-xl border border-[#F1F5F9] elevation-2">
                <span className="font-bold text-[#0F172A] block text-xs">Level 2: Active Sheets</span>
                <span className="text-[10px] text-[#64748B] block mt-0.5">
                  0px 8px 24px rgba(6, 78, 59, 0.08)
                </span>
              </div>
              <div className="p-3 bg-white rounded-xl border border-[#F1F5F9] elevation-3">
                <span className="font-bold text-[#0F172A] block text-xs">Level 3: Pinned Nav</span>
                <span className="text-[10px] text-[#64748B] block mt-0.5">
                  0px -4px 20px blur(16px) backdrop
                </span>
              </div>
            </div>
          </div>

          {/* Typography Scale */}
          <div>
            <h4 className="font-bold text-[#0F172A] text-sm mb-2.5 flex items-center gap-1.5">
              <Type size={15} className="text-[#059669]" />
              Typography & Tabular Numerics
            </h4>
            <div className="p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-2">
              <div className="flex justify-between items-baseline">
                <span className="text-xs text-[#64748B]">Display-LG Mobile (32px Bold)</span>
                <span className="text-2xl font-bold text-[#0F172A] tabular-nums">$14,820.50</span>
              </div>
              <div className="flex justify-between items-baseline border-t border-[#E2E8F0] pt-2">
                <span className="text-xs text-[#64748B]">Headline-SM (18px Bold)</span>
                <span className="text-base font-bold text-[#0F172A]">Emergency Savings</span>
              </div>
              <div className="flex justify-between items-baseline border-t border-[#E2E8F0] pt-2">
                <span className="text-xs text-[#64748B]">Body-MD (14px Regular)</span>
                <span className="text-xs text-[#334155]">Organic Produce & Pantry</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-[#F1F5F9] bg-[#FAFAFA] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#059669] text-white font-semibold text-xs hover:bg-[#00855d] transition-all"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
