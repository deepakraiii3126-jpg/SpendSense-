import React, { useState } from 'react';
import { ShieldCheck, Plus, Check, Target, ChevronRight, Sparkles } from 'lucide-react';
import { SavingsGoal } from '../types';

interface EmergencySavingsCardProps {
  goal: SavingsGoal;
  currencySymbol: string;
  onDeposit: (goalId: string, amount: number) => void;
  onOpenVaults: () => void;
}

export const EmergencySavingsCard: React.FC<EmergencySavingsCardProps> = ({
  goal,
  currencySymbol,
  onDeposit,
  onOpenVaults,
}) => {
  const [showQuickDeposit, setShowQuickDeposit] = useState(false);
  const [customAmount, setCustomAmount] = useState('');
  const [recentDepositFeedback, setRecentDepositFeedback] = useState(false);

  const percentage = Math.min(100, Math.round((goal.currentAmount / goal.targetAmount) * 100));

  const formatMoney = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(val);
  };

  const handleDepositClick = (amount: number) => {
    onDeposit(goal.id, amount);
    setRecentDepositFeedback(true);
    setTimeout(() => setRecentDepositFeedback(false), 2000);
    setShowQuickDeposit(false);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(customAmount);
    if (!isNaN(val) && val > 0) {
      handleDepositClick(val);
      setCustomAmount('');
    }
  };

  return (
    <div
      id="emergency-savings-card"
      className="w-full bg-white rounded-2xl p-4 sm:p-5 border border-[#F1F5F9] elevation-1 hover:elevation-2 transition-all"
    >
      {/* Header with category icon badge: 40px circular container with #ECFDF5 fill and #059669 iconography */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#ECFDF5] text-[#059669] flex items-center justify-center border border-[#D1FAE5] shrink-0">
            <ShieldCheck size={20} />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-base font-bold text-[#0F172A]">
                {goal.name}
              </h2>
              {percentage >= 80 && (
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-[#ECFDF5] text-[#059669] border border-[#A7F3D0]">
                  Strong
                </span>
              )}
            </div>
            <p className="text-xs text-[#64748B]">
              Recommended 3-6 months living expenses
            </p>
          </div>
        </div>

        <button
          onClick={onOpenVaults}
          className="text-xs font-semibold text-[#059669] hover:text-[#006948] flex items-center gap-0.5 p-1 transition-colors"
        >
          <span>Vaults</span>
          <ChevronRight size={14} />
        </button>
      </div>

      {/* Target & Current Figures */}
      <div className="flex items-baseline justify-between mb-2">
        <div className="flex items-baseline gap-1">
          <span className="text-2xl font-bold text-[#0F172A] tabular-nums">
            {currencySymbol}{formatMoney(goal.currentAmount)}
          </span>
          <span className="text-xs font-medium text-[#64748B] tabular-nums">
            of {currencySymbol}{formatMoney(goal.targetAmount)} target
          </span>
        </div>
        <div className="text-sm font-bold text-[#059669] tabular-nums">
          {percentage}%
        </div>
      </div>

      {/* Progress Track: High-contrast soft rounded height 10px, bg #D1FAE5, fill #059669 to #10B981 with milestone dots */}
      <div className="relative w-full py-1">
        <div className="relative h-2.5 w-full bg-[#D1FAE5] rounded-full overflow-hidden">
          {/* Progress fill */}
          <div
            className="h-full rounded-full transition-all duration-700 ease-out"
            style={{
              width: `${percentage}%`,
              background: 'linear-gradient(90deg, #059669 0%, #10B981 100%)',
            }}
          />
        </div>

        {/* Milestone Indicators: Segmented step dots (6px diameter) inset into the track */}
        <div className="absolute top-1/2 -translate-y-1/2 left-0 right-0 w-full pointer-events-none px-1">
          <div className="relative w-full h-2.5">
            {goal.milestones.map((ms, index) => {
              const msPercent = (ms / goal.targetAmount) * 100;
              const isPassed = goal.currentAmount >= ms;
              return (
                <div
                  key={index}
                  className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center"
                  style={{ left: `${msPercent}%` }}
                >
                  <div
                    className={`w-2 h-2 rounded-full border border-white transition-all ${
                      isPassed ? 'bg-[#064E3B]' : 'bg-[#94A3B8]'
                    }`}
                    title={`Milestone ${index + 1}: ${currencySymbol}${formatMoney(ms)}`}
                  />
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Milestone Threshold Labels below track */}
      <div className="flex justify-between items-center text-[10px] font-semibold text-[#64748B] mt-1.5 px-0.5 tabular-nums">
        <span>{currencySymbol}0</span>
        {goal.milestones.map((ms, idx) => (
          <span
            key={idx}
            className={goal.currentAmount >= ms ? 'text-[#059669] font-bold' : 'text-[#64748B]'}
          >
            {currencySymbol}{ms >= 1000 ? `${Math.round(ms / 1000)}k` : ms}
          </span>
        ))}
      </div>

      {/* Quick Boost / Deposit Row */}
      <div className="mt-3 pt-3 border-t border-[#F1F5F9] flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          {(currencySymbol === '₹' ? [500, 1000, 2500] : [50, 100, 250]).map((amt, index) => (
            <button
              key={amt}
              onClick={() => handleDepositClick(amt)}
              className={`px-2.5 py-1 rounded-full text-xs font-semibold transition-all active:scale-95 ${
                index === 2
                  ? 'bg-[#ECFDF5] text-[#064E3B] hover:bg-[#D1FAE5]'
                  : 'bg-[#F1F5F9] hover:bg-[#ECFDF5] text-[#334155] hover:text-[#059669]'
              }`}
            >
              +{currencySymbol}{amt >= 1000 ? amt.toLocaleString() : amt}
            </button>
          ))}
        </div>

        <button
          onClick={() => setShowQuickDeposit(!showQuickDeposit)}
          className="text-xs font-semibold text-[#059669] hover:text-[#006948] flex items-center gap-1 transition-colors"
        >
          <Plus size={13} />
          <span>Custom Deposit</span>
        </button>
      </div>

      {/* Custom Deposit expansion form */}
      {showQuickDeposit && (
        <form onSubmit={handleCustomSubmit} className="mt-2 pt-2 flex items-center gap-2">
          <div className="relative flex-1">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748B] text-sm font-semibold">
              {currencySymbol}
            </span>
            <input
              type="number"
              placeholder="Amount to save"
              value={customAmount}
              onChange={(e) => setCustomAmount(e.target.value)}
              className="w-full h-9 pl-7 pr-3 text-sm bg-white border border-[#CBD5E1] rounded-lg focus:outline-none focus:border-[#059669] focus:ring-2 focus:ring-[#059669]/20 tabular-nums"
              autoFocus
            />
          </div>
          <button
            type="submit"
            className="h-9 px-3.5 rounded-lg bg-[#059669] text-white text-xs font-semibold hover:bg-[#00855d] active:scale-95 transition-all"
          >
            Save
          </button>
        </form>
      )}

      {recentDepositFeedback && (
        <div className="mt-2 p-2 rounded-lg bg-[#ECFDF5] border border-[#A7F3D0] flex items-center gap-2 text-xs font-medium text-[#064E3B] animate-fade-in">
          <Sparkles size={14} className="text-[#059669]" />
          <span>Saved towards Emergency Fund! Well done.</span>
        </div>
      )}
    </div>
  );
};
