import React, { useState, useEffect } from 'react';
import { X, Smartphone, QrCode, Copy, Check, ExternalLink, Share2, Compass, MoreVertical } from 'lucide-react';
import QRCode from 'qrcode';

interface GetOnPhoneModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GetOnPhoneModal: React.FC<GetOnPhoneModalProps> = ({ isOpen, onClose }) => {
  const [activePlatform, setActivePlatform] = useState<'ios' | 'android'>('ios');
  const [copied, setCopied] = useState(false);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');

  // Target current URL or preview URL
  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://ais-pre-mamhg3s6avt366bnenc6bb-277951959830.asia-southeast1.run.app';

  useEffect(() => {
    if (!isOpen) return;

    // Generate crisp QR code
    QRCode.toDataURL(currentUrl, {
      width: 220,
      margin: 1.5,
      color: {
        dark: '#064E3B',
        light: '#FFFFFF',
      },
    })
      .then((url) => setQrCodeDataUrl(url))
      .catch((err) => console.error('Failed to generate QR code', err));
  }, [isOpen, currentUrl]);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0F172A]/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-2xl elevation-4 border border-[#E2E8F0] overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-[#F1F5F9] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#ECFDF5] text-[#059669] flex items-center justify-center border border-[#A7F3D0]/60">
              <Smartphone size={18} />
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#0F172A] tracking-tight">
                Get SpendSense on Your Phone
              </h2>
              <p className="text-[11px] text-[#64748B]">
                Install as a full-screen home screen web app
              </p>
            </div>
          </div>
          <button
            id="close-get-phone-modal-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-full text-[#64748B] hover:text-[#0F172A] hover:bg-[#F1F5F9] flex items-center justify-center transition-all"
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-5 overflow-y-auto space-y-5 text-[#0F172A]">
          {/* Method 1: Scan QR Code */}
          <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl p-4 text-center">
            <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-[#059669] mb-2 uppercase tracking-wider">
              <QrCode size={14} />
              <span>Step 1: Scan with Phone Camera</span>
            </div>

            <div className="inline-block p-2.5 bg-white rounded-xl shadow-xs border border-[#E2E8F0] my-1">
              {qrCodeDataUrl ? (
                <img
                  src={qrCodeDataUrl}
                  alt="QR Code to open SpendSense"
                  className="w-40 h-40 object-contain mx-auto"
                />
              ) : (
                <div className="w-40 h-40 flex items-center justify-center text-xs text-[#94A3B8]">
                  Generating QR...
                </div>
              )}
            </div>

            <p className="text-xs text-[#475569] mt-2">
              Point your iPhone camera or Android QR scanner at this code to open the app directly.
            </p>
          </div>

          {/* Method 2: Share / Copy Link */}
          <div>
            <label className="text-xs font-semibold text-[#475569] block mb-1.5">
              Or copy link to send to yourself:
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={currentUrl}
                className="flex-1 h-9 px-3 bg-[#F1F5F9] border border-[#E2E8F0] rounded-xl text-xs text-[#475569] font-mono truncate select-all focus:outline-none"
              />
              <button
                id="copy-phone-link-btn"
                onClick={handleCopyLink}
                className="h-9 px-3.5 rounded-xl bg-[#059669] hover:bg-[#00855d] text-white text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95 shadow-xs"
              >
                {copied ? <Check size={14} /> : <Copy size={14} />}
                <span>{copied ? 'Copied!' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Platform Instructions (iOS vs Android) */}
          <div className="pt-2 border-t border-[#F1F5F9]">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-[#0F172A]">
                Step 2: Add to Home Screen
              </span>
              <div className="flex bg-[#F1F5F9] p-0.5 rounded-lg text-xs font-semibold">
                <button
                  onClick={() => setActivePlatform('ios')}
                  className={`px-3 py-1 rounded-md transition-all ${
                    activePlatform === 'ios'
                      ? 'bg-white text-[#059669] shadow-xs'
                      : 'text-[#64748B] hover:text-[#0F172A]'
                  }`}
                >
                  iPhone (iOS)
                </button>
                <button
                  onClick={() => setActivePlatform('android')}
                  className={`px-3 py-1 rounded-md transition-all ${
                    activePlatform === 'android'
                      ? 'bg-white text-[#059669] shadow-xs'
                      : 'text-[#64748B] hover:text-[#0F172A]'
                  }`}
                >
                  Android
                </button>
              </div>
            </div>

            {/* iOS Instructions */}
            {activePlatform === 'ios' ? (
              <div className="space-y-2.5 bg-[#F8FAFC] p-3.5 rounded-xl border border-[#E2E8F0] text-xs">
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#ECFDF5] text-[#059669] font-bold flex items-center justify-center shrink-0 text-[11px]">
                    1
                  </span>
                  <p className="text-[#334155]">
                    Open the link in <strong>Safari</strong> (default browser on iPhone).
                  </p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#ECFDF5] text-[#059669] font-bold flex items-center justify-center shrink-0 text-[11px]">
                    2
                  </span>
                  <p className="text-[#334155] flex items-center gap-1 flex-wrap">
                    Tap the <strong>Share</strong> button <Share2 size={13} className="inline text-[#059669]" /> in the bottom toolbar.
                  </p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#ECFDF5] text-[#059669] font-bold flex items-center justify-center shrink-0 text-[11px]">
                    3
                  </span>
                  <p className="text-[#334155]">
                    Scroll down and tap <strong>"Add to Home Screen"</strong> with the plus icon.
                  </p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#ECFDF5] text-[#059669] font-bold flex items-center justify-center shrink-0 text-[11px]">
                    4
                  </span>
                  <p className="text-[#334155]">
                    Tap <strong>Add</strong> at top right. SpendSense will now launch as a clean native app on your home screen!
                  </p>
                </div>
              </div>
            ) : (
              /* Android Instructions */
              <div className="space-y-2.5 bg-[#F8FAFC] p-3.5 rounded-xl border border-[#E2E8F0] text-xs">
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#ECFDF5] text-[#059669] font-bold flex items-center justify-center shrink-0 text-[11px]">
                    1
                  </span>
                  <p className="text-[#334155]">
                    Open the link in <strong>Google Chrome</strong>.
                  </p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#ECFDF5] text-[#059669] font-bold flex items-center justify-center shrink-0 text-[11px]">
                    2
                  </span>
                  <p className="text-[#334155] flex items-center gap-1 flex-wrap">
                    Tap the <strong>three dots</strong> <MoreVertical size={13} className="inline text-[#059669]" /> menu at top right.
                  </p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#ECFDF5] text-[#059669] font-bold flex items-center justify-center shrink-0 text-[11px]">
                    3
                  </span>
                  <p className="text-[#334155]">
                    Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.
                  </p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#ECFDF5] text-[#059669] font-bold flex items-center justify-center shrink-0 text-[11px]">
                    4
                  </span>
                  <p className="text-[#334155]">
                    Tap <strong>Install</strong> to add the SpendSense icon and enjoy instant offline access.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#F8FAFC] border-t border-[#F1F5F9] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-white border border-[#E2E8F0] text-xs font-bold text-[#334155] hover:bg-[#F1F5F9] transition-all"
          >
            Got it, thanks!
          </button>
        </div>
      </div>
    </div>
  );
};
