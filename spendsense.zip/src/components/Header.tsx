import React from 'react';
import { Bell, Plus } from 'lucide-react';
import { SpenSenseLogo } from './SpenSenseLogo';

interface HeaderProps {
  selectedPeriod: string;
  onQuickAdd: () => void;
  onOpenNotifications: () => void;
  unreadCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  selectedPeriod,
  onQuickAdd,
  onOpenNotifications,
  unreadCount = 2,
}) => {
  return (
    <header className="w-full bg-white border-b border-[#F1F5F9] sticky top-0 z-30 transition-all">
      <div className="max-w-xl mx-auto px-4 py-3 sm:px-5 flex items-center justify-between gap-3">
        {/* Left: Brand Identity */}
        <div className="flex items-center gap-3">
          <SpenSenseLogo size={38} showText={true} />
          
          <div className="hidden sm:flex items-center text-xs font-semibold px-2.5 py-1 rounded-full bg-[#ECFDF5] text-[#064E3B] border border-[#D1FAE5]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#059669] mr-1.5 animate-pulse"></span>
            {selectedPeriod}
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          {/* Quick Add Transaction Button (Same size as notification icon) */}
          <button
            id="header-quick-add-btn"
            onClick={onQuickAdd}
            className="w-9 h-9 rounded-full bg-[#059669] hover:bg-[#00855d] active:scale-95 text-white flex items-center justify-center transition-all shadow-xs"
            aria-label="Add Transaction"
            title="Add Transaction"
          >
            <Plus size={19} strokeWidth={2.5} />
          </button>

          {/* Notifications */}
          <button
            id="header-notifications-btn"
            onClick={onOpenNotifications}
            className="relative w-9 h-9 rounded-full text-[#334155] hover:bg-[#F1F5F9] active:scale-95 transition-all flex items-center justify-center"
            aria-label="Notifications"
            title="Notifications"
          >
            <Bell size={19} />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-[#E11D48] text-white text-[10px] font-bold flex items-center justify-center border-2 border-white">
                {unreadCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
