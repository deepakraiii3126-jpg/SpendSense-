import React, { useState } from 'react';
import {
  Lock,
  Mail,
  ArrowRight,
  Eye,
  EyeOff,
  ShieldCheck,
  User as UserIcon,
} from 'lucide-react';
import { SpenSenseLogo } from './SpenSenseLogo';

interface LoginScreenProps {
  onLogin: (userName?: string) => void;
  defaultName?: string;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onLogin,
  defaultName = 'Dizz',
}) => {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [emailOrPhone, setEmailOrPhone] = useState('dizz@spendsense.app');
  const [password, setPassword] = useState('••••••••');
  const [showPassword, setShowPassword] = useState(false);
  const [name, setName] = useState(defaultName);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin(mode === 'signup' && name ? name : defaultName);
    }, 600);
  };

  const handleQuickLoginAsDizz = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin(defaultName);
    }, 400);
  };

  return (
    <div className="min-h-screen w-full bg-[#F8FAFC] flex flex-col justify-center items-center p-4 sm:p-6 animate-fade-in select-none">
      <div className="w-full max-w-sm bg-white rounded-3xl border border-[#E2E8F0] elevation-2 p-6 sm:p-7 overflow-hidden">
        {/* Brand Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <SpenSenseLogo size={52} showText={false} className="mb-3" />
          <h1 className="text-xl font-bold text-[#0F172A] tracking-tight">
            SpendSense
          </h1>
        </div>

        {/* Quick 1-Tap Access for Dizz */}
        {mode === 'signin' && (
          <div className="mb-5 p-3.5 rounded-2xl bg-[#F0FDF4] border border-[#A7F3D0] flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-full bg-white border border-[#A7F3D0] flex items-center justify-center text-[#059669] shadow-xs">
                <UserIcon size={18} />
              </div>
              <div className="text-left">
                <p className="text-xs font-bold text-[#064E3B]">{defaultName}</p>
                <p className="text-[11px] text-[#059669]">Quick 1-Tap Sign In</p>
              </div>
            </div>
            <button
              id="quick-login-dizz-btn"
              type="button"
              onClick={handleQuickLoginAsDizz}
              disabled={isLoading}
              className="px-3.5 py-1.5 rounded-xl bg-[#059669] hover:bg-[#00855d] active:scale-95 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1"
            >
              <span>Continue</span>
              <ArrowRight size={13} />
            </button>
          </div>
        )}

        {/* Mode Toggle Tabs */}
        <div className="flex bg-[#F1F5F9] p-1 rounded-xl mb-5 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setMode('signin')}
            className={`flex-1 py-1.5 rounded-lg transition-all ${
              mode === 'signin'
                ? 'bg-white text-[#0F172A] shadow-xs'
                : 'text-[#64748B] hover:text-[#0F172A]'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => setMode('signup')}
            className={`flex-1 py-1.5 rounded-lg transition-all ${
              mode === 'signup'
                ? 'bg-white text-[#0F172A] shadow-xs'
                : 'text-[#64748B] hover:text-[#0F172A]'
            }`}
          >
            Create Account
          </button>
        </div>

        {/* Credentials Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {mode === 'signup' && (
            <div>
              <label className="block text-xs font-bold text-[#475569] mb-1">
                Your Name
              </label>
              <div className="relative">
                <UserIcon
                  size={15}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]"
                />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Dizz"
                  className="w-full h-10 pl-9 pr-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] focus:bg-white focus:outline-none focus:border-[#059669]"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-[#475569] mb-1">
              Email or Phone Number
            </label>
            <div className="relative">
              <Mail
                size={15}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]"
              />
              <input
                type="text"
                required
                value={emailOrPhone}
                onChange={(e) => setEmailOrPhone(e.target.value)}
                placeholder="name@domain.com or +91..."
                className="w-full h-10 pl-9 pr-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] focus:bg-white focus:outline-none focus:border-[#059669]"
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-xs font-bold text-[#475569]">
                {mode === 'signin' ? 'Security PIN / Password' : 'Set Password'}
              </label>
              {mode === 'signin' && (
                <button
                  type="button"
                  onClick={() => alert('Demo passcode hint: You can click "Continue" above or type any 4-digit PIN.')}
                  className="text-[11px] font-semibold text-[#059669] hover:underline"
                >
                  Forgot?
                </button>
              )}
            </div>
            <div className="relative">
              <Lock
                size={15}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]"
              />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full h-10 pl-9 pr-9 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] focus:bg-white focus:outline-none focus:border-[#059669]"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#94A3B8] hover:text-[#475569]"
              >
                {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="w-4 h-4 rounded border-[#CBD5E1] text-[#059669] focus:ring-[#059669]"
              />
              <span className="text-xs text-[#64748B]">Remember this device</span>
            </label>
          </div>

          {/* Primary Submit Button */}
          <button
            id="login-submit-btn"
            type="submit"
            disabled={isLoading}
            className="w-full h-11 mt-2 rounded-xl bg-[#059669] hover:bg-[#00855d] active:scale-98 text-white text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-sm"
          >
            {isLoading ? (
              <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>{mode === 'signin' ? 'Sign In' : 'Create Account'}</span>
                <ArrowRight size={15} />
              </>
            )}
          </button>
        </form>

        {/* Security badge footer */}
        <div className="mt-5 flex items-center justify-center gap-1.5 text-[10px] text-[#94A3B8]">
          <ShieldCheck size={12} className="text-[#059669]" />
          <span>256-Bit Encrypted Offline Storage</span>
        </div>
      </div>
    </div>
  );
};
