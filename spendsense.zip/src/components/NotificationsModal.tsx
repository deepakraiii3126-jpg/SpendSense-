import React from 'react';
import { X, Bell, AlertTriangle, ArrowUpRight, ShieldCheck, Check } from 'lucide-react';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currencySymbol: string;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  currencySymbol,
}) => {
  if (!isOpen) return null;

  const notifications = [
    {
      id: 'notif-1',
      title: 'Budget Alert: Dining & Groceries',
      message: `You have reached 86% of your ${currencySymbol}${currencySymbol === '₹' ? '16,000' : '800'} envelope with 14 days remaining in the billing cycle.`,
      time: '2 hours ago',
      type: 'warning',
      icon: AlertTriangle,
      color: 'bg-[#FFFBEB] text-[#D97706] border-[#FDE68A]',
    },
    {
      id: 'notif-2',
      title: 'Emergency Fund Milestone Reached',
      message: `Congratulations! Your Emergency Savings reached 84% (${currencySymbol}${currencySymbol === '₹' ? '2,10,000' : '8,400'}) toward your ${currencySymbol}${currencySymbol === '₹' ? '2,50,000' : '10,000'} threshold.`,
      time: 'Yesterday',
      type: 'success',
      icon: ShieldCheck,
      color: 'bg-[#ECFDF5] text-[#059669] border-[#A7F3D0]',
    },
    {
      id: 'notif-3',
      title: 'Income Inflow Settled',
      message: `Direct bank deposit of ${currencySymbol}${currencySymbol === '₹' ? '42,500.00' : '3,225.00'} from Acme Corp Payroll was credited.`,
      time: '2 days ago',
      type: 'income',
      icon: ArrowUpRight,
      color: 'bg-[#ECFDF5] text-[#059669] border-[#A7F3D0]',
    },
  ];

  return (
    <div
      id="notifications-modal"
      className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-3 sm:p-4 bg-[#0F172A]/40 backdrop-blur-xs animate-fade-in"
    >
      <div className="w-full max-w-md bg-white rounded-2xl elevation-3 border border-[#E2E8F0] mt-16 sm:mt-0 overflow-hidden">
        <div className="p-4 border-b border-[#F1F5F9] flex items-center justify-between bg-[#FAFAFA]">
          <div className="flex items-center gap-2">
            <Bell size={18} className="text-[#059669]" />
            <h3 className="text-sm font-bold text-[#0F172A]">
              Alerts & Notifications
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-[#64748B] hover:bg-white"
          >
            <X size={16} />
          </button>
        </div>

        <div className="p-4 space-y-3 divide-y divide-[#F1F5F9]">
          {notifications.map((n) => {
            const Icon = n.icon;
            return (
              <div key={n.id} className="pt-3 first:pt-0 flex items-start gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center border shrink-0 ${n.color}`}>
                  <Icon size={16} />
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-[#0F172A]">
                      {n.title}
                    </h4>
                    <span className="text-[10px] text-[#64748B]">{n.time}</span>
                  </div>
                  <p className="text-xs text-[#64748B] mt-0.5 leading-relaxed">
                    {n.message}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="p-3 bg-[#FAFAFA] border-t border-[#F1F5F9] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#059669] text-white text-xs font-semibold hover:bg-[#00855d]"
          >
            Mark all read
          </button>
        </div>
      </div>
    </div>
  );
};
