import React, { useState } from 'react';
import {
  X,
  User,
  Shield,
  Download,
  RotateCcw,
  Sparkles,
  ExternalLink,
  CreditCard,
  Bell,
  Check,
  LogOut,
} from 'lucide-react';
import { UserProfile, Transaction } from '../types';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  onUpdateProfile: (updated: Partial<UserProfile>) => void;
  onResetData: () => void;
  transactions: Transaction[];
  onOpenDesignSystem?: () => void;
  onLogout?: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  profile,
  onUpdateProfile,
  onResetData,
  transactions,
  onOpenDesignSystem,
  onLogout,
}) => {
  const [name, setName] = useState(profile.name);
  const [currencySymbol, setCurrencySymbol] = useState(profile.currencySymbol);
  const [monthlyIncome, setMonthlyIncome] = useState(profile.monthlyIncome.toString());
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      name,
      currencySymbol,
      monthlyIncome: parseFloat(monthlyIncome) || profile.monthlyIncome,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 1500);
  };

  const handleExportCSV = () => {
    const headers = ['ID', 'Title', 'Category', 'Subcategory', 'Amount', 'Type', 'Date', 'PaymentMethod'];
    const rows = transactions.map((t) => [
      t.id,
      `"${t.title.replace(/"/g, '""')}"`,
      `"${t.category}"`,
      `"${t.subcategory || ''}"`,
      t.amount,
      t.type,
      t.date,
      `"${t.paymentMethod}"`,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'spendsense_transactions.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div
      id="profile-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-[#0F172A]/40 backdrop-blur-xs animate-fade-in"
    >
      <div className="w-full max-w-md bg-white rounded-2xl elevation-3 border border-[#E2E8F0] max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#F1F5F9] flex items-center justify-between">
          <h2 className="text-base font-bold text-[#0F172A]">
            Account & Preferences
          </h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-[#64748B] hover:bg-[#F1F5F9] transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Profile Card */}
        <div className="p-5">
          <div className="flex items-center gap-3.5 pb-4 border-b border-[#F1F5F9]">
            <div className="relative">
              <div className="w-14 h-14 rounded-full bg-[#F1F5F9] border-2 border-[#E2E8F0] flex items-center justify-center text-[#94A3B8]">
                <User size={26} strokeWidth={1.75} />
              </div>
            </div>

            <div>
              <h3 className="text-base font-bold text-[#0F172A]">
                {profile.name}
              </h3>
              <div className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#ECFDF5] text-[#059669] mt-1 border border-[#A7F3D0]">
                <Shield size={10} />
                <span>Verified Financial Identity</span>
              </div>
            </div>
          </div>

          {/* Form Settings */}
          <form onSubmit={handleSave} className="space-y-3.5 my-4">
            <div>
              <label className="block text-xs font-bold text-[#64748B] mb-1">
                Display Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full h-10 px-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] focus:bg-white focus:outline-none focus:border-[#059669]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-[#64748B] mb-1">
                  Currency Symbol
                </label>
                <select
                  value={currencySymbol}
                  onChange={(e) => setCurrencySymbol(e.target.value)}
                  className="w-full h-10 px-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] focus:bg-white focus:outline-none focus:border-[#059669]"
                >
                  <option value="₹">₹ (INR - Indian Rupee)</option>
                  <option value="$">$ (USD / CAD / AUD)</option>
                  <option value="€">€ (EUR)</option>
                  <option value="£">£ (GBP)</option>
                  <option value="¥">¥ (JPY)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#64748B] mb-1">
                  Monthly Baseline ({currencySymbol})
                </label>
                <input
                  type="number"
                  value={monthlyIncome}
                  onChange={(e) => setMonthlyIncome(e.target.value)}
                  className="w-full h-10 px-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] focus:bg-white focus:outline-none focus:border-[#059669]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full h-10 rounded-xl bg-[#059669] text-white text-xs font-semibold hover:bg-[#00855d] active:scale-95 transition-all flex items-center justify-center gap-1.5"
            >
              {savedSuccess ? (
                <>
                  <Check size={14} />
                  <span>Preferences Saved!</span>
                </>
              ) : (
                <span>Save Preferences</span>
              )}
            </button>
          </form>

          {/* Data Actions */}
          <div className="pt-3 border-t border-[#F1F5F9] space-y-2">
            {onOpenDesignSystem && (
              <button
                onClick={() => {
                  onClose();
                  onOpenDesignSystem();
                }}
                className="w-full h-10 px-3 rounded-xl bg-[#ECFDF5] hover:bg-[#D1FAE5] text-xs font-semibold text-[#064E3B] flex items-center justify-center gap-2 transition-all active:scale-95 border border-[#A7F3D0]"
              >
                <Sparkles size={14} className="text-[#059669]" />
                <span>View Design System Specifications</span>
              </button>
            )}

            <button
              onClick={handleExportCSV}
              className="w-full h-10 px-3 rounded-xl bg-[#F1F5F9] hover:bg-[#E2E8F0] text-xs font-semibold text-[#334155] flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              <Download size={14} />
              <span>Export {transactions.length} Transactions (CSV)</span>
            </button>

            <button
              onClick={() => {
                if (window.confirm('Reset all transactions and goals to default demo state?')) {
                  onResetData();
                  onClose();
                }
              }}
              className="w-full h-10 px-3 rounded-xl bg-[#FFF1F2] hover:bg-[#FFE4E6] text-xs font-semibold text-[#E11D48] flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              <RotateCcw size={14} />
              <span>Reset to Sample Ledger</span>
            </button>

            {onLogout && (
              <button
                onClick={() => {
                  onClose();
                  onLogout();
                }}
                className="w-full h-10 px-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] hover:bg-[#F1F5F9] text-xs font-semibold text-[#64748B] hover:text-[#0F172A] flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                <LogOut size={14} />
                <span>Sign Out of SpendSense</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
