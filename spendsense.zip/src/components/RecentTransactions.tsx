import React, { useState } from 'react';
import {
  ShoppingCart,
  Briefcase,
  Coffee,
  Activity,
  Music,
  Sparkles,
  Zap,
  Car,
  ShoppingBag,
  BookOpen,
  ArrowUpRight,
  Filter,
  Search,
  CheckCircle2,
} from 'lucide-react';
import { Transaction } from '../types';

interface RecentTransactionsProps {
  transactions: Transaction[];
  currencySymbol: string;
  onSelectTransaction: (tx: Transaction) => void;
  onViewAll?: () => void;
  isFullView?: boolean;
}

const iconRegistry: Record<string, React.ElementType> = {
  ShoppingCart,
  Briefcase,
  Coffee,
  Activity,
  Music,
  Sparkles,
  Zap,
  Car,
  ShoppingBag,
  BookOpen,
};

export const RecentTransactions: React.FC<RecentTransactionsProps> = ({
  transactions,
  currencySymbol,
  onSelectTransaction,
  onViewAll,
  isFullView = false,
}) => {
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filterChips = [
    { id: 'all', label: 'All' },
    { id: 'expenses', label: 'Expenses' },
    { id: 'income', label: 'Income' },
    { id: 'subscriptions', label: 'Subscriptions' },
  ];

  // Filter logic
  const filtered = transactions.filter((tx) => {
    if (activeFilter === 'expenses' && tx.type !== 'expense') return false;
    if (activeFilter === 'income' && tx.type !== 'income') return false;
    if (activeFilter === 'subscriptions' && !tx.isSubscription) return false;

    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const matchTitle = tx.title.toLowerCase().includes(q);
      const matchCat = tx.category.toLowerCase().includes(q);
      const matchSub = tx.subcategory?.toLowerCase().includes(q);
      return matchTitle || matchCat || matchSub;
    }
    return true;
  });

  const displayList = isFullView ? filtered : filtered.slice(0, 5);

  const formatAmount = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(val);
  };

  const formatDateLabel = (dateStr: string) => {
    const today = '2026-09-16';
    const yesterday = '2026-09-15';
    if (dateStr === today) return 'Today';
    if (dateStr === yesterday) return 'Yesterday';

    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  return (
    <div
      id="recent-transactions-card"
      className="w-full bg-white rounded-2xl p-4 sm:p-5 border border-[#F1F5F9] elevation-1 transition-all"
    >
      {/* Title & View All */}
      <div className="flex items-center justify-between mb-3.5">
        <div>
          <h2 className="text-base font-bold text-[#0F172A]">
            {isFullView ? 'Transaction Ledger' : 'Recent Transactions'}
          </h2>
          <p className="text-xs text-[#64748B]">
            {filtered.length} {filtered.length === 1 ? 'item' : 'items'} tracked this cycle
          </p>
        </div>

        {onViewAll && !isFullView && (
          <button
            onClick={onViewAll}
            className="text-xs font-semibold text-[#059669] hover:text-[#006948] transition-colors p-1"
          >
            See All →
          </button>
        )}
      </div>

      {/* Search Input if Full View */}
      {isFullView && (
        <div className="relative mb-3">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#64748B]" />
          <input
            type="text"
            placeholder="Search transactions, notes, vendors..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-10 pl-9 pr-4 text-xs sm:text-sm bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl focus:bg-white focus:outline-none focus:border-[#059669] focus:ring-2 focus:ring-[#059669]/20 transition-all"
          />
        </div>
      )}

      {/* Filter Chips: Pill-shaped tags with 12px typography */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none mb-3">
        {filterChips.map((chip) => {
          const isActive = activeFilter === chip.id;
          return (
            <button
              key={chip.id}
              onClick={() => setActiveFilter(chip.id)}
              className={`text-[12px] font-semibold px-3 py-1.5 rounded-full whitespace-nowrap transition-all active:scale-95 ${
                isActive
                  ? 'bg-[#064E3B] text-white shadow-xs'
                  : 'bg-[#F1F5F9] text-[#334155] hover:bg-[#E2E8F0]'
              }`}
            >
              {chip.label}
            </button>
          );
        })}
      </div>

      {/* Transaction List: 64px row items with 40px category icon container */}
      <div className="divide-y divide-[#F1F5F9]">
        {displayList.length === 0 ? (
          <div className="py-8 text-center text-xs text-[#64748B]">
            No transactions found matching this filter.
          </div>
        ) : (
          displayList.map((tx) => {
            const Icon = iconRegistry[tx.icon] || ShoppingBag;
            const isIncome = tx.type === 'income';

            return (
              <div
                key={tx.id}
                onClick={() => onSelectTransaction(tx)}
                className="h-16 flex items-center justify-between gap-3 px-1 py-2 hover:bg-[#F8FAFC] rounded-xl cursor-pointer transition-colors active:bg-[#F1F5F9] group"
              >
                {/* Left: 40px category icon container with #ECFDF5 fill and #059669 iconography */}
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-full bg-[#ECFDF5] text-[#059669] flex items-center justify-center border border-[#D1FAE5] shrink-0 group-hover:scale-105 transition-transform">
                    <Icon size={18} />
                  </div>

                  {/* 2-line textual meta: Title + Subcategory / Timestamp */}
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-semibold text-[#0F172A] truncate">
                        {tx.title}
                      </span>
                      {tx.isSubscription && (
                        <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-[#EAEDFF] text-[#283044] border border-[#CBD5E1]">
                          Sub
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-[#64748B] truncate flex items-center gap-1.5">
                      <span>{tx.subcategory || tx.category}</span>
                      <span>•</span>
                      <span>{formatDateLabel(tx.date)}</span>
                    </div>
                  </div>
                </div>

                {/* Right: Right-aligned tabular currency value */}
                <div className="text-right shrink-0">
                  <div
                    className={`text-sm font-bold tabular-nums ${
                      isIncome ? 'text-[#059669]' : 'text-[#0F172A]'
                    }`}
                  >
                    {isIncome ? '+' : '-'}
                    {currencySymbol}
                    {formatAmount(tx.amount)}
                  </div>
                  <div className="text-[10px] text-[#64748B]">
                    {tx.paymentMethod.split(' ')[0]}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
