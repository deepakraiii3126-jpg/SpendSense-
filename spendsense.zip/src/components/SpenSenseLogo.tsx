import React from 'react';

interface SpenSenseLogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
  textColor?: string;
}

export const SpenSenseLogo: React.FC<SpenSenseLogoProps> = ({
  className = '',
  size = 40,
  showText = false,
  textColor = '#0F172A',
}) => {
  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 transition-transform active:scale-95"
      >
        <defs>
          <linearGradient id="spensense-bg-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#059669" />
            <stop offset="100%" stopColor="#006948" />
          </linearGradient>
          <filter id="soft-shadow" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#064E3B" floodOpacity="0.15" />
          </filter>
        </defs>

        {/* Squircle container with soft rounded corners */}
        <rect
          x="2"
          y="2"
          width="96"
          height="96"
          rx="26"
          fill="url(#spensense-bg-grad)"
        />

        {/* Subtle tactile inner border highlight */}
        <rect
          x="3"
          y="3"
          width="94"
          height="94"
          rx="25"
          stroke="rgba(255, 255, 255, 0.2)"
          strokeWidth="1.5"
          fill="none"
        />

        {/* Distinctive SpenSense "S" curve */}
        <path
          d="M 68 28
             C 68 28 60 21 48 21
             C 34 21 28 30 28 39
             C 28 50 38 54 50 58
             C 66 63 72 68 72 79
             C 72 90 60 98 46 98
             C 32 98 25 90 25 90"
          stroke="#FFFFFF"
          strokeWidth="11"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />

        {/* Signature mint dot inside the upper loop */}
        <circle
          cx="56"
          cy="38"
          r="6.5"
          fill="#A7F3D0"
        />
      </svg>

      {showText && (
        <div className="flex flex-col">
          <span
            className="font-bold tracking-tight text-lg leading-none"
            style={{ color: textColor }}
          >
            SpendSense
          </span>
        </div>
      )}
    </div>
  );
};
