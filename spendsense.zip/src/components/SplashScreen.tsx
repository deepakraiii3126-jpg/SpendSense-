import React, { useEffect, useState } from 'react';
import { SpenSenseLogo } from './SpenSenseLogo';

interface SplashScreenProps {
  onFinish: () => void;
  duration?: number;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onFinish,
  duration = 2000,
}) => {
  const [fadingOut, setFadingOut] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const startTime = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(pct);

      if (elapsed >= duration - 400) {
        setFadingOut(true);
      }

      if (elapsed >= duration) {
        clearInterval(interval);
        onFinish();
      }
    }, 40);

    return () => clearInterval(interval);
  }, [duration, onFinish]);

  return (
    <div
      onClick={onFinish}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-between p-8 bg-[#0F172A] text-white transition-opacity duration-400 select-none cursor-pointer ${
        fadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Subtle background ambient glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-[#059669]/20 rounded-full blur-3xl pointer-events-none" />

      {/* Top spacing */}
      <div className="w-full flex justify-between items-center text-xs text-[#64748B]">
        <span className="font-semibold tracking-wider uppercase text-[10px] text-[#059669]">
          Tactile Fintech
        </span>
        <span className="text-[11px] font-mono">v1.2.0</span>
      </div>

      {/* Center Brand Identity */}
      <div className="relative flex flex-col items-center text-center animate-fade-in">
        {/* Animated Icon */}
        <div className="relative mb-6">
          <div className="absolute inset-0 rounded-3xl bg-[#059669] blur-xl opacity-40 animate-pulse" />
          <SpenSenseLogo size={84} showText={false} className="relative z-10 drop-shadow-2xl" />
        </div>

        {/* Title & Tagline */}
        <h1 className="text-3xl font-extrabold text-white tracking-tight">
          SpendSense
        </h1>
        <p className="text-sm text-[#94A3B8] mt-2 max-w-xs font-medium">
          Smart budgeting, tactile wealth & emergency milestones.
        </p>
      </div>

      {/* Bottom Loading Progress Bar */}
      <div className="w-full max-w-xs flex flex-col items-center gap-3">
        <div className="w-full h-1 bg-[#1E293B] rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-[#059669] to-[#34D399] rounded-full transition-all duration-75"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex justify-between w-full text-[11px] text-[#64748B]">
          <span>Loading secure vault...</span>
          <span className="font-mono text-[#059669]">{progress}%</span>
        </div>
        <p className="text-[10px] text-[#475569] mt-1">Tap anywhere to skip</p>
      </div>
    </div>
  );
};
