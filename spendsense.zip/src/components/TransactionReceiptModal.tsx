import React from 'react';
import { X, Trash2, CheckCircle2, ArrowDownRight, ArrowUpRight, Share2, Calendar, CreditCard, Tag, FileText } from 'lucide-react';
import { Transaction } from '../types';

interface TransactionReceiptModalProps {
  transaction: Transaction | null;
  onClose: () => void;
  onDelete: (id: string) => void;
  currencySymbol: string;
}

export const TransactionReceiptModal: React.FC<TransactionReceiptModalProps> = ({
  transaction,
  onClose,
  onDelete,
  currencySymbol,
}) => {
  if (!transaction) return null;

  const isIncome = transaction.type === 'income';

  const formatAmount = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(val);
  };

  return (
    <div
      id="transaction-receipt-modal"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-[#0F172A]/40 backdrop-blur-xs animate-fade-in"
    >
      <div className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-2xl p-5 sm:p-6 elevation-3 border border-[#E2E8F0]">
        {/* Top bar */}
        <div className="flex items-center justify-between pb-3 border-b border-[#F1F5F9] mb-4">
          <span className="text-xs font-bold uppercase tracking-wider text-[#64748B]">
            Transaction Receipt
          </span>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-[#64748B] hover:bg-[#F1F5F9] transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Amount & Status Hero */}
        <div className="text-center py-3">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#ECFDF5] text-[#059669] mb-2 border border-[#D1FAE5]">
            {isIncome ? <ArrowUpRight size={24} /> : <ArrowDownRight size={24} className="text-[#E11D48]" />}
          </div>
          <div
            className={`text-3xl font-bold tabular-nums tracking-tight ${
              isIncome ? 'text-[#059669]' : 'text-[#0F172A]'
            }`}
          >
            {isIncome ? '+' : '-'}{currencySymbol}{formatAmount(transaction.amount)}
          </div>
          <h3 className="text-base font-bold text-[#0F172A] mt-1">
            {transaction.title}
          </h3>
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-0.5 rounded-full bg-[#ECFDF5] text-[#059669] mt-2 border border-[#A7F3D0]">
            <CheckCircle2 size={12} />
            <span>Completed & Settled</span>
          </div>
        </div>

        {/* Receipt Ledger Details */}
        <div className="my-4 p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-2.5 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-[#64748B] flex items-center gap-1.5">
              <Tag size={14} />
              Category
            </span>
            <span className="font-semibold text-[#0F172A]">
              {transaction.category} {transaction.subcategory ? `› ${transaction.subcategory}` : ''}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-[#64748B] flex items-center gap-1.5">
              <Calendar size={14} />
              Date & Time
            </span>
            <span className="font-semibold text-[#0F172A]">
              {transaction.date} {transaction.time ? `at ${transaction.time}` : ''}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-[#64748B] flex items-center gap-1.5">
              <CreditCard size={14} />
              Payment Method
            </span>
            <span className="font-semibold text-[#0F172A]">
              {transaction.paymentMethod}
            </span>
          </div>

          {transaction.notes && (
            <div className="flex items-start justify-between pt-1 border-t border-[#E2E8F0]/60">
              <span className="text-[#64748B] flex items-center gap-1.5 shrink-0">
                <FileText size={14} />
                Memo / Note
              </span>
              <span className="font-medium text-[#334155] text-right ml-4">
                {transaction.notes}
              </span>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 pt-2">
          <button
            onClick={() => {
              onDelete(transaction.id);
              onClose();
            }}
            className="flex items-center justify-center gap-1.5 h-11 px-4 rounded-xl bg-[#FFF1F2] text-[#E11D48] hover:bg-[#FFE4E6] text-xs font-semibold transition-all active:scale-95"
            title="Remove transaction"
          >
            <Trash2 size={15} />
            <span>Remove</span>
          </button>

          <button
            onClick={onClose}
            className="flex-1 h-11 rounded-xl bg-[#059669] text-white text-xs font-semibold hover:bg-[#00855d] active:scale-95 transition-all flex items-center justify-center gap-1.5"
          >
            <span>Close Receipt</span>
          </button>
        </div>
      </div>
    </div>
  );
};
