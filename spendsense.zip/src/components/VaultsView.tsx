import React, { useState } from 'react';
import {
  ShieldCheck,
  Plane,
  Laptop,
  Plus,
  Target,
  Sparkles,
  TrendingUp,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import { SavingsGoal } from '../types';

interface VaultsViewProps {
  goals: SavingsGoal[];
  currencySymbol: string;
  onDeposit: (goalId: string, amount: number) => void;
  onAddGoal: (goal: Omit<SavingsGoal, 'id'>) => void;
}

const iconMap: Record<string, React.ElementType> = {
  ShieldCheck,
  Plane,
  Laptop,
  Target,
};

export const VaultsView: React.FC<VaultsViewProps> = ({
  goals,
  currencySymbol,
  onDeposit,
  onAddGoal,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newGoalName, setNewGoalName] = useState('');
  const [newGoalTarget, setNewGoalTarget] = useState('');
  const [newGoalCategory, setNewGoalCategory] = useState('Travel');
  const [selectedGoalId, setSelectedGoalId] = useState<string | null>(null);
  const [depositVal, setDepositVal] = useState('');

  const formatMoney = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(val);
  };

  const totalSaved = goals.reduce((sum, g) => sum + g.currentAmount, 0);
  const totalTarget = goals.reduce((sum, g) => sum + g.targetAmount, 0);
  const overallPercentage = Math.round((totalSaved / totalTarget) * 100);

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    const target = parseFloat(newGoalTarget);
    if (!newGoalName || isNaN(target) || target <= 0) return;

    onAddGoal({
      name: newGoalName,
      category: newGoalCategory,
      targetAmount: target,
      currentAmount: 0,
      milestones: [target * 0.25, target * 0.5, target * 0.75, target],
      color: '#059669',
      targetDate: '2027',
      icon: 'Target',
    });

    setNewGoalName('');
    setNewGoalTarget('');
    setShowAddModal(false);
  };

  const handleDepositSubmit = (goalId: string) => {
    const val = parseFloat(depositVal);
    if (!isNaN(val) && val > 0) {
      onDeposit(goalId, val);
      setDepositVal('');
      setSelectedGoalId(null);
    }
  };

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Vaults Overview Banner */}
      <div className="bg-gradient-to-br from-[#064E3B] to-[#006948] text-white rounded-2xl p-5 elevation-2 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-44 h-44 bg-[#A7F3D0]/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
              <Lock size={16} className="text-[#A7F3D0]" />
            </div>
            <span className="text-xs font-semibold uppercase tracking-wider text-[#A7F3D0]">
              Dedicated Savings Vaults
            </span>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white text-[#064E3B] text-xs font-bold hover:bg-[#A7F3D0] active:scale-95 transition-all shadow-xs"
          >
            <Plus size={14} />
            <span>New Vault</span>
          </button>
        </div>

        <div className="flex items-baseline gap-1 my-1">
          <span className="text-2xl font-bold text-[#A7F3D0]">
            {currencySymbol}
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight tabular-nums">
            {formatMoney(totalSaved)}
          </h2>
          <span className="text-sm font-medium text-[#A7F3D0]/80 ml-2">
            of {currencySymbol}{formatMoney(totalTarget)} target ({overallPercentage}%)
          </span>
        </div>

        <div className="w-full h-2 bg-white/20 rounded-full mt-3 overflow-hidden">
          <div
            className="h-full bg-[#10B981] rounded-full transition-all duration-700"
            style={{ width: `${overallPercentage}%` }}
          />
        </div>
      </div>

      {/* Individual Goals List */}
      <div className="space-y-3.5">
        {goals.map((goal) => {
          const Icon = iconMap[goal.icon] || Target;
          const pct = Math.min(100, Math.round((goal.currentAmount / goal.targetAmount) * 100));
          const isDepositOpen = selectedGoalId === goal.id;

          return (
            <div
              key={goal.id}
              className="bg-white rounded-2xl p-4 sm:p-5 border border-[#F1F5F9] elevation-1 hover:elevation-2 transition-all"
            >
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#ECFDF5] text-[#059669] flex items-center justify-center border border-[#D1FAE5] shrink-0">
                    <Icon size={20} />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-[#0F172A]">
                      {goal.name}
                    </h3>
                    <p className="text-xs text-[#64748B]">
                      {goal.category} • Target: {goal.targetDate}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-base font-bold text-[#0F172A] tabular-nums">
                    {currencySymbol}{formatMoney(goal.currentAmount)}
                  </span>
                  <div className="text-xs text-[#64748B] tabular-nums">
                    of {currencySymbol}{formatMoney(goal.targetAmount)}
                  </div>
                </div>
              </div>

              {/* Progress track with segmented milestone dots */}
              <div className="relative w-full py-1">
                <div className="relative h-2.5 w-full bg-[#D1FAE5] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-700 ease-out"
                    style={{
                      width: `${pct}%`,
                      background: 'linear-gradient(90deg, #059669 0%, #10B981 100%)',
                    }}
                  />
                </div>

                {/* Milestone Indicators */}
                <div className="absolute top-1/2 -translate-y-1/2 left-0 right-0 w-full pointer-events-none px-1">
                  <div className="relative w-full h-2.5">
                    {goal.milestones.map((ms, index) => {
                      const msPercent = (ms / goal.targetAmount) * 100;
                      const isPassed = goal.currentAmount >= ms;
                      return (
                        <div
                          key={index}
                          className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center"
                          style={{ left: `${msPercent}%` }}
                        >
                          <div
                            className={`w-2 h-2 rounded-full border border-white transition-all ${
                              isPassed ? 'bg-[#064E3B]' : 'bg-[#94A3B8]'
                            }`}
                          />
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Action buttons row */}
              <div className="mt-3 pt-3 border-t border-[#F1F5F9] flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => onDeposit(goal.id, 50)}
                    className="px-2.5 py-1 rounded-full bg-[#F1F5F9] hover:bg-[#ECFDF5] text-xs font-semibold text-[#334155] hover:text-[#059669] transition-all"
                  >
                    +$50
                  </button>
                  <button
                    onClick={() => onDeposit(goal.id, 100)}
                    className="px-2.5 py-1 rounded-full bg-[#F1F5F9] hover:bg-[#ECFDF5] text-xs font-semibold text-[#334155] hover:text-[#059669] transition-all"
                  >
                    +$100
                  </button>
                </div>

                <button
                  onClick={() => setSelectedGoalId(isDepositOpen ? null : goal.id)}
                  className="text-xs font-semibold text-[#059669] hover:text-[#006948] flex items-center gap-1 transition-colors"
                >
                  <Plus size={13} />
                  <span>Deposit Amount</span>
                </button>
              </div>

              {/* Deposit Drawer */}
              {isDepositOpen && (
                <div className="mt-3 pt-3 border-t border-[#E2E8F0] flex items-center gap-2">
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748B] text-xs font-bold">
                      {currencySymbol}
                    </span>
                    <input
                      type="number"
                      placeholder="Deposit amount"
                      value={depositVal}
                      onChange={(e) => setDepositVal(e.target.value)}
                      className="w-full h-9 pl-7 pr-3 text-xs bg-white border border-[#CBD5E1] rounded-lg focus:outline-none focus:border-[#059669]"
                      autoFocus
                    />
                  </div>
                  <button
                    onClick={() => handleDepositSubmit(goal.id)}
                    className="h-9 px-4 rounded-lg bg-[#059669] text-white text-xs font-semibold hover:bg-[#00855d] transition-colors"
                  >
                    Confirm
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Add Goal Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0F172A]/40 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white rounded-2xl p-5 border border-[#E2E8F0] elevation-3">
            <h3 className="text-base font-bold text-[#0F172A] mb-3">
              Create New Savings Vault
            </h3>
            <form onSubmit={handleCreateGoal} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-[#64748B]">Vault Name</label>
                <input
                  type="text"
                  placeholder="e.g. Wedding, New Car, Tokyo Trip"
                  value={newGoalName}
                  onChange={(e) => setNewGoalName(e.target.value)}
                  className="w-full h-10 px-3 mt-1 bg-white border border-[#E2E8F0] rounded-xl text-xs font-semibold focus:outline-none focus:border-[#059669]"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#64748B]">Target Amount ({currencySymbol})</label>
                <input
                  type="number"
                  placeholder="e.g. 5000"
                  value={newGoalTarget}
                  onChange={(e) => setNewGoalTarget(e.target.value)}
                  className="w-full h-10 px-3 mt-1 bg-white border border-[#E2E8F0] rounded-xl text-xs font-semibold focus:outline-none focus:border-[#059669]"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#64748B]">Category</label>
                <select
                  value={newGoalCategory}
                  onChange={(e) => setNewGoalCategory(e.target.value)}
                  className="w-full h-10 px-3 mt-1 bg-white border border-[#E2E8F0] rounded-xl text-xs font-semibold focus:outline-none focus:border-[#059669]"
                >
                  <option value="Travel & Experiences">Travel & Experiences</option>
                  <option value="Safety Net">Safety Net</option>
                  <option value="Equipment & Tech">Equipment & Tech</option>
                  <option value="Home & Living">Home & Living</option>
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 h-10 rounded-xl bg-[#F1F5F9] text-xs font-bold text-[#334155]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 h-10 rounded-xl bg-[#059669] text-white text-xs font-bold hover:bg-[#00855d]"
                >
                  Create Vault
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
