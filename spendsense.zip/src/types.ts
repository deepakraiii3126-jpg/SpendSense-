export type TransactionType = 'expense' | 'income';

export interface Transaction {
  id: string;
  title: string;
  category: string;
  subcategory?: string;
  amount: number; // positive number; type determines +/-
  type: TransactionType;
  date: string; // ISO string or YYYY-MM-DD
  time?: string;
  paymentMethod: string;
  notes?: string;
  status: 'completed' | 'pending';
  icon: string;
  isSubscription?: boolean;
}

export interface CategoryBudget {
  id: string;
  name: string;
  icon: string;
  allocated: number;
  spent: number;
  color: string;
  isWarning?: boolean;
}

export interface Milestone {
  targetAmount: number;
  label: string;
  reached: boolean;
}

export interface SavingsGoal {
  id: string;
  name: string;
  category: string;
  targetAmount: number;
  currentAmount: number;
  milestones: number[];
  color: string;
  targetDate: string;
  icon: string;
}

export interface UserProfile {
  name: string;
  handle: string;
  avatarUrl: string;
  currency: string;
  currencySymbol: string;
  monthlyIncome: number;
  monthlyBudget: number;
  savingsRate: number;
}
